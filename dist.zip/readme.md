# Acode Lint

Check syntax error in your code.

**NOTE:** It may not work properly on Acode version lower than v1.6.0 (222). Please update acode to latest version.

## Supported languages

- Coffee
- CSS
- HTML
- Javascript
- JSON
- Lua
- PHP
- XML
- XQuery
- YAML
